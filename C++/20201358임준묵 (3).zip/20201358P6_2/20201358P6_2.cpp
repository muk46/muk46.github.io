#include <iostream>
using namespace std;

class Student
{
	int m_id; 
	int m_score;
public: Student(int id, int score); 
	  void Show_Student();
	  void Add_Score(int score);
	  Student Max_Student(Student& ob);
};
Student::Student(int id, int score) 
{
	m_id = id;
	m_score = score;;
}
void Student::Show_Student()
{
	cout << "�й� = " << m_id << " : ���� = " << m_score << "��\n";
}
void Student::Add_Score(int score)
{
	m_score += score; 
}
	
Student Student::Max_Student(Student& ob)
{
	if (m_score > ob.m_score) return *this; 
	else
		return ob; 
}

	int main()
	{ 
		Student max[1] = { Student(0, 0) };
		Student arr[3] = { Student(20101111, 86), Student(20111111, 83), Student(20121111, 92) };
		arr[0].Add_Score(10); 
		cout << "--- �迭 arr[ ] ��� ������ �� ---\n";
		for (int i = 0; i < 3; i++) arr[i].Show_Student();
		// �ִ� ���� ã��
		*max = arr[0];
		for (int i = 1; i < 3; i++)
			*max = max->Max_Student(arr[i]); 
		cout << "\n--- �迭 arr[ ] ��ü �� �ִ� ������ ---\n";
		max->Show_Student(); 

		system("PAUSE");
		return 0;
	}