#include <iostream>
#include <string>
using namespace std;

class Person {
public:
    enum SEX { male, female };
protected:
    string m_name;
    int m_age;
    SEX m_sex;
public:
    Person();
    Person(string name, int age, SEX sex);
    void Print();
};

Person::Person() {
    m_age = 0;
    m_sex = male;
}

Person::Person(string name, int age, SEX sex) {
    m_name = name;
    m_age = age;
    m_sex = sex;
}

void Person::Print() {
    cout << "�̸�: " << m_name << ", ����: " << m_age;
}

class Man : public Person {
public:
    Man() {}
    Man(string name, int age);
    void Print();
};

Man::Man(string name, int age) : Person(name, age, male) {
}

void Man::Print() {
    Person::Print();
    cout << ", ����: M \n";
}

class Woman : public Person {
public:
    Woman() {}
    Woman(string name, int age);
    void Print();
};

Woman::Woman(string name, int age) : Person(name, age, female) {
}

void Woman::Print() {
    Person::Print();
    cout << ", ����: F \n";
}

int main() {
    Man m1("���켺", 44);
    m1.Print();

    Woman w1("��ȿ��", 38);
    w1.Print();

    system("PAUSE");
    return 0;
}